# Print Mission Central v3

Print Mission Central is a local-only 3D printer camera wall for Android TV / Fire TV devices with a companion server for Windows or Linux.

## What changed in v3

- TV app now supports **token-based pairing**
- TV app saves the **server URL**, **API token**, **layout name**, and initial admin credentials locally
- TV app can reconnect automatically on next launch
- Server keeps **basic auth** for the admin UI
- Server exposes **token-authenticated TV API** for dashboards
- UDP discovery updated to **PMC_DISCOVER_V2**
- Admin UI now includes a **TV pairing** section and shows paired device tokens
- Black dashboard background and electric blue camera borders remain the defaults
- Layout editor, printer names, camera health, and theme controls remain included

## Server

Default admin login:
- Username: `admin`
- Password: `admin`

Run:
- Windows: `start-windows.bat`
- Linux: `./start-linux.sh`

Admin UI:
- `http://YOUR-SERVER-IP:8181/`

## TV App connection flow

1. Launch the app
2. Let it auto-discover if possible, or enter the server URL manually
3. Enter admin login once
4. Press **Pair and Connect**
5. The app saves the server URL, API token, and layout locally
6. On next launch it attempts automatic reconnect

## API auth model

- Admin UI and admin API use **Basic Auth**
- TV dashboard API uses a per-device **X-PMC-Token** issued by `/api/pair`

## Android build

Open `android-app/` in Android Studio and build the APK there.
A prebuilt APK is not included because this environment does not include the Android SDK / Gradle build chain.

## Ownership

See `ATTRIBUTION_AND_OWNERSHIP.md`.
