# Print Mission Central Android App

Android TV / Fire TV / Android landscape dashboard for local 3D printer IP cameras.

## Added in this version
- UDP auto-discovery of the local server
- Black background dashboard
- Electric-blue camera tile outlines by default
- Outline/background theme pulled from the local server
- Printer name shown on every camera tile
- Health badge on every tile
- Settings screen for fallback manual server entry

## Build requirements
- Android Studio Iguana or newer
- Android SDK 34
- JDK 17+
- Gradle sync from Android Studio

## Build
Open `android-app/` in Android Studio and build the `app` module.

## Notes
This environment did not include the Android SDK/Gradle toolchain needed to emit a signed APK directly, so the updated source is included and ready to open in Android Studio.
