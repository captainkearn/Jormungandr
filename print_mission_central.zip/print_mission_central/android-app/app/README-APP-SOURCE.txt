Source files for the Android TV / Fire TV app live under app/src/main/java and app/src/main/res.
