package com.captainkearn.printmissioncentral.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "pmc_settings")

class SettingsStore(private val context: Context) {
    private val serverUrlKey = stringPreferencesKey("server_url")
    private val layoutNameKey = stringPreferencesKey("layout_name")

    val serverUrl: Flow<String> = context.dataStore.data.map { it[serverUrlKey] ?: "http://192.168.1.10:8181/" }
    val layoutName: Flow<String> = context.dataStore.data.map { it[layoutNameKey] ?: "Default" }

    suspend fun saveServerUrl(url: String) {
        context.dataStore.edit { it[serverUrlKey] = url }
    }

    suspend fun saveLayoutName(name: String) {
        context.dataStore.edit { it[layoutNameKey] = name }
    }
}
