package com.captainkearn.printmissioncentral.data

import retrofit2.http.GET
import retrofit2.http.Path

interface PrintMissionApi {
    @GET("api/dashboard/{layout}")
    suspend fun getDashboard(@Path("layout") layout: String): DashboardResponse
}
