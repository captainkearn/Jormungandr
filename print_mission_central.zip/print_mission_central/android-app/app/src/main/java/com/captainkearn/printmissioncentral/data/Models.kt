package com.captainkearn.printmissioncentral.data

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class CameraDto(
    val id: String,
    val name: String,
    val url: String,
    @SerialName("stream_type") val streamType: String,
    val enabled: Boolean = true,
    val notes: String = ""
)

@Serializable
data class LayoutItemDto(
    @SerialName("camera_id") val cameraId: String,
    val row: Int,
    val col: Int,
    @SerialName("row_span") val rowSpan: Int = 1,
    @SerialName("col_span") val colSpan: Int = 1,
    val camera: CameraDto
)

@Serializable
data class DashboardResponse(
    val layout: String,
    val rows: Int,
    val cols: Int,
    val items: List<LayoutItemDto>
)
