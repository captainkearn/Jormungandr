package com.captainkearn.printmissioncentral

import android.annotation.SuppressLint
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.weight
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color as ComposeColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import okhttp3.Credentials
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import retrofit2.Retrofit
import retrofit2.converter.kotlinx.serialization.asConverterFactory
import retrofit2.http.GET
import retrofit2.http.Header
import retrofit2.http.Path
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.util.concurrent.TimeUnit

private val ComponentActivity.dataStore by preferencesDataStore(name = "pmc_settings")

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                AppScreen(activity = this)
            }
        }
    }
}

@Serializable
data class ThemeSettings(
    @SerialName("background_color") val backgroundColor: String = "#000000",
    @SerialName("tile_outline_color") val tileOutlineColor: String = "#00B7FF",
)

@Serializable
data class Camera(
    val id: String,
    @SerialName("printer_name") val printerName: String,
    val url: String,
    @SerialName("stream_type") val streamType: String,
    val enabled: Boolean = true,
    val notes: String = "",
)

@Serializable
data class Health(
    val status: String = "unknown",
    val healthy: Boolean = false,
    val detail: String = "",
)

@Serializable
data class LayoutItem(
    @SerialName("camera_id") val cameraId: String,
    val row: Int,
    val col: Int,
    @SerialName("row_span") val rowSpan: Int = 1,
    @SerialName("col_span") val colSpan: Int = 1,
    val camera: Camera,
    val health: Health,
)

@Serializable
data class DashboardResponse(
    val layout: String,
    val rows: Int,
    val cols: Int,
    val items: List<LayoutItem>,
    val theme: ThemeSettings = ThemeSettings(),
    @SerialName("default_layout") val defaultLayout: String? = null,
)

@Serializable
data class DiscoveryResponse(
    val name: String,
    @SerialName("api_base") val apiBase: String,
    @SerialName("web_ui") val webUi: String,
)

@Serializable
data class PairRequest(
    @SerialName("device_name") val deviceName: String,
)

@Serializable
data class PairResponse(
    val token: String,
    val server: String,
    @SerialName("default_layout") val defaultLayout: String? = null,
    val theme: ThemeSettings = ThemeSettings(),
)

interface PmcApi {
    @GET("api/dashboard/{layout}")
    suspend fun dashboard(
        @Path("layout") layout: String,
        @Header("X-PMC-Token") token: String,
    ): DashboardResponse
}

@Composable
fun AppScreen(activity: ComponentActivity) {
    val scope = rememberCoroutineScope()
    var serverUrl by remember { mutableStateOf("") }
    var layoutName by remember { mutableStateOf("Default") }
    var adminUser by remember { mutableStateOf("admin") }
    var adminPass by remember { mutableStateOf("admin") }
    var deviceName by remember { mutableStateOf("Living Room TV") }
    var savedToken by remember { mutableStateOf<String?>(null) }
    var dashboard by remember { mutableStateOf<DashboardResponse?>(null) }
    var message by remember { mutableStateOf("Searching for local Print Mission Central server...") }
    var showSettings by remember { mutableStateOf(true) }

    LaunchedEffect(Unit) {
        val prefs = activity.dataStore.data.first()
        serverUrl = prefs[stringPreferencesKey("server_url")] ?: ""
        layoutName = prefs[stringPreferencesKey("layout_name")] ?: "Default"
        savedToken = prefs[stringPreferencesKey("api_token")]
        adminUser = prefs[stringPreferencesKey("admin_user")] ?: "admin"
        adminPass = prefs[stringPreferencesKey("admin_pass")] ?: "admin"
        deviceName = prefs[stringPreferencesKey("device_name")] ?: "Living Room TV"

        if (serverUrl.isBlank()) {
            discoverServer()?.let {
                serverUrl = it.apiBase
                message = "Discovered ${it.apiBase}"
            }
        }

        if (!serverUrl.isBlank() && !savedToken.isNullOrBlank()) {
            runCatching { fetchDashboard(serverUrl, layoutName, savedToken!!) }
                .onSuccess {
                    dashboard = it
                    layoutName = it.defaultLayout ?: layoutName
                    showSettings = false
                    message = "Connected to saved server"
                }
                .onFailure {
                    message = "Saved connection failed. Pair again or verify the server URL."
                    showSettings = true
                }
        } else {
            showSettings = true
            if (serverUrl.isBlank()) {
                message = "No local server discovered automatically. Enter the server URL and pair."
            }
        }
    }

    val bg = dashboard?.theme?.backgroundColor?.toComposeColorSafe() ?: ComposeColor.Black

    Box(modifier = Modifier.fillMaxSize().background(bg)) {
        if (showSettings || dashboard == null) {
            SettingsPanel(
                serverUrl = serverUrl,
                layoutName = layoutName,
                adminUser = adminUser,
                adminPass = adminPass,
                deviceName = deviceName,
                message = message,
                onServerUrlChange = { serverUrl = it },
                onLayoutNameChange = { layoutName = it },
                onAdminUserChange = { adminUser = it },
                onAdminPassChange = { adminPass = it },
                onDeviceNameChange = { deviceName = it },
                onDiscover = {
                    scope.launch {
                        val found = discoverServer()
                        if (found != null) {
                            serverUrl = found.apiBase
                            message = "Discovered ${found.apiBase}"
                        } else {
                            message = "Discovery did not find a local server. Enter the server URL manually."
                        }
                    }
                },
                onPairAndConnect = {
                    scope.launch {
                        try {
                            val normalized = serverUrl.trim().removeSuffix("/")
                            val pair = pairDevice(normalized, adminUser, adminPass, deviceName)
                            val effectiveLayout = if (layoutName.isBlank()) pair.defaultLayout ?: "Default" else layoutName
                            val loaded = fetchDashboard(normalized, effectiveLayout, pair.token)
                            dashboard = loaded
                            savedToken = pair.token
                            layoutName = effectiveLayout
                            showSettings = false
                            message = "Connected to ${pair.server}"
                            activity.dataStore.edit {
                                it[stringPreferencesKey("server_url")] = normalized
                                it[stringPreferencesKey("layout_name")] = effectiveLayout
                                it[stringPreferencesKey("api_token")] = pair.token
                                it[stringPreferencesKey("admin_user")] = adminUser
                                it[stringPreferencesKey("admin_pass")] = adminPass
                                it[stringPreferencesKey("device_name")] = deviceName
                            }
                        } catch (e: Exception) {
                            message = e.message ?: "Pairing failed"
                        }
                    }
                }
            )
        } else {
            DashboardView(
                dashboard = dashboard!!,
                onOpenSettings = { showSettings = true },
                onRefresh = {
                    scope.launch {
                        val token = savedToken
                        if (token.isNullOrBlank()) {
                            message = "Missing saved API token. Pair again."
                            showSettings = true
                            return@launch
                        }
                        runCatching { fetchDashboard(serverUrl, layoutName, token) }
                            .onSuccess { dashboard = it }
                            .onFailure {
                                message = it.message ?: "Refresh failed"
                                showSettings = true
                            }
                    }
                }
            )
        }
    }
}

@Composable
fun SettingsPanel(
    serverUrl: String,
    layoutName: String,
    adminUser: String,
    adminPass: String,
    deviceName: String,
    message: String,
    onServerUrlChange: (String) -> Unit,
    onLayoutNameChange: (String) -> Unit,
    onAdminUserChange: (String) -> Unit,
    onAdminPassChange: (String) -> Unit,
    onDeviceNameChange: (String) -> Unit,
    onDiscover: () -> Unit,
    onPairAndConnect: () -> Unit,
) {
    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Card(
            colors = CardDefaults.cardColors(containerColor = ComposeColor(0xFF101821)),
            modifier = Modifier.width(780.dp)
        ) {
            Column(modifier = Modifier.padding(24.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                Text("Print Mission Central", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, color = ComposeColor.White)
                Text(message, color = ComposeColor(0xFF9BB4D0))
                OutlinedTextField(value = serverUrl, onValueChange = onServerUrlChange, label = { Text("Server URL") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = layoutName, onValueChange = onLayoutNameChange, label = { Text("Layout name") }, modifier = Modifier.fillMaxWidth())
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                    OutlinedTextField(value = adminUser, onValueChange = onAdminUserChange, label = { Text("Admin user") }, modifier = Modifier.weight(1f))
                    OutlinedTextField(value = adminPass, onValueChange = onAdminPassChange, label = { Text("Admin password") }, modifier = Modifier.weight(1f))
                }
                OutlinedTextField(value = deviceName, onValueChange = onDeviceNameChange, label = { Text("This TV name") }, modifier = Modifier.fillMaxWidth())
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Button(onClick = onDiscover) { Text("Auto-discover") }
                    Button(onClick = onPairAndConnect) { Text("Pair and Connect") }
                }
            }
        }
    }
}

@Composable
fun DashboardView(dashboard: DashboardResponse, onOpenSettings: () -> Unit, onRefresh: () -> Unit) {
    val outline = dashboard.theme.tileOutlineColor.toComposeColorSafe(default = ComposeColor(0xFF00B7FF))
    Column(modifier = Modifier.fillMaxSize().padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(
                text = "${dashboard.layout} · ${dashboard.items.size} cameras",
                color = ComposeColor.White,
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold,
            )
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                TextButton(onClick = onRefresh) { Text("Refresh") }
                TextButton(onClick = onOpenSettings) { Text("Settings") }
            }
        }
        LazyVerticalGrid(
            columns = GridCells.Fixed(dashboard.cols.coerceAtLeast(1)),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            items(dashboard.items, key = { it.cameraId }) { item ->
                CameraTile(item = item, outline = outline)
            }
        }
    }
}

@Composable
fun CameraTile(item: LayoutItem, outline: ComposeColor) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .height((180 * item.rowSpan).dp)
            .clip(RoundedCornerShape(18.dp))
            .border(2.dp, outline, RoundedCornerShape(18.dp))
            .background(ComposeColor(0xFF071018))
            .padding(10.dp)
            .focusable(),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Column {
                Text(item.camera.printerName, color = ComposeColor.White, fontWeight = FontWeight.Bold)
                Text(item.camera.id, color = ComposeColor(0xFFA8BEDA))
            }
            HealthBadge(item.health)
        }
        Box(modifier = Modifier.fillMaxSize().clip(RoundedCornerShape(14.dp)).background(ComposeColor.Black)) {
            when (item.camera.streamType.lowercase()) {
                "mjpeg", "snapshot" -> MjpegView(item.camera.url)
                "rtsp", "hls" -> PlayerTile(item.camera.url)
                else -> Text("Unsupported stream type", color = ComposeColor.White, modifier = Modifier.align(Alignment.Center))
            }
        }
    }
}

@Composable
fun HealthBadge(health: Health) {
    val color = if (health.healthy) ComposeColor(0xFF26D07C) else ComposeColor(0xFFFF5B73)
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(999.dp))
            .background(color.copy(alpha = 0.18f))
            .border(1.dp, color, RoundedCornerShape(999.dp))
            .padding(horizontal = 10.dp, vertical = 6.dp)
    ) {
        Text(health.status.uppercase(), color = color, fontWeight = FontWeight.Bold)
    }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun MjpegView(url: String) {
    AndroidView(factory = { context ->
        WebView(context).apply {
            setBackgroundColor(Color.BLACK)
            webViewClient = WebViewClient()
            webChromeClient = WebChromeClient()
            settings.javaScriptEnabled = false
            settings.cacheMode = WebSettings.LOAD_NO_CACHE
            settings.loadWithOverviewMode = true
            settings.useWideViewPort = true
            loadUrl(url)
        }
    }, modifier = Modifier.fillMaxSize())
}

@Composable
fun PlayerTile(url: String) {
    val context = LocalContext.current
    val player = remember(url) {
        ExoPlayer.Builder(context).build().apply {
            setMediaItem(MediaItem.fromUri(Uri.parse(url)))
            prepare()
            playWhenReady = true
        }
    }
    AndroidView(factory = {
        PlayerView(it).apply {
            useController = false
            this.player = player
            setShutterBackgroundColor(Color.BLACK)
        }
    }, modifier = Modifier.fillMaxSize())
}

suspend fun pairDevice(serverUrl: String, username: String, password: String, deviceName: String): PairResponse = withContext(Dispatchers.IO) {
    val client = OkHttpClient.Builder().connectTimeout(4, TimeUnit.SECONDS).readTimeout(8, TimeUnit.SECONDS).build()
    val json = Json { ignoreUnknownKeys = true }
    val reqBody = json.encodeToString(PairRequest.serializer(), PairRequest(deviceName)).toRequestBody("application/json".toMediaType())
    val request = Request.Builder()
        .url(serverUrl.ensureTrailingSlash() + "api/pair")
        .header("Authorization", Credentials.basic(username, password))
        .post(reqBody)
        .build()
    client.newCall(request).execute().use { response ->
        if (!response.isSuccessful) {
            throw IllegalStateException("Pairing failed: HTTP ${response.code}")
        }
        val body = response.body?.string() ?: throw IllegalStateException("Empty pairing response")
        json.decodeFromString(PairResponse.serializer(), body)
    }
}

suspend fun fetchDashboard(serverUrl: String, layoutName: String, token: String): DashboardResponse = withContext(Dispatchers.IO) {
    val json = Json { ignoreUnknownKeys = true }
    val retrofit = Retrofit.Builder()
        .baseUrl(serverUrl.ensureTrailingSlash())
        .client(OkHttpClient.Builder().connectTimeout(4, TimeUnit.SECONDS).readTimeout(8, TimeUnit.SECONDS).build())
        .addConverterFactory(json.asConverterFactory("application/json".toMediaType()))
        .build()
    retrofit.create(PmcApi::class.java).dashboard(layoutName, token)
}

suspend fun discoverServer(): DiscoveryResponse? = withContext(Dispatchers.IO) {
    val socket = DatagramSocket().apply { broadcast = true; soTimeout = 2200 }
    val payload = "PMC_DISCOVER_V2".toByteArray()
    val packet = DatagramPacket(payload, payload.size, InetAddress.getByName("255.255.255.255"), 8182)
    return@withContext try {
        socket.send(packet)
        val buf = ByteArray(4096)
        val resp = DatagramPacket(buf, buf.size)
        socket.receive(resp)
        Json { ignoreUnknownKeys = true }.decodeFromString(DiscoveryResponse.serializer(), String(resp.data, 0, resp.length))
    } catch (_: Exception) {
        null
    } finally {
        socket.close()
    }
}

fun String.ensureTrailingSlash(): String = if (endsWith('/')) this else "$this/"

fun String.toComposeColorSafe(default: ComposeColor = ComposeColor.Black): ComposeColor {
    return try {
        ComposeColor(Color.parseColor(this))
    } catch (_: Exception) {
        default
    }
}
