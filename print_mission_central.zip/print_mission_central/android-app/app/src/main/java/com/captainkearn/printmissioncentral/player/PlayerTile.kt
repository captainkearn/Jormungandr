package com.captainkearn.printmissioncentral.player

import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import com.captainkearn.printmissioncentral.data.CameraDto

@Composable
fun PlayerTile(camera: CameraDto, modifier: Modifier = Modifier) {
    when (camera.streamType.lowercase()) {
        "mjpeg", "snapshot" -> MjpegView(url = camera.url, modifier = modifier)
        "rtsp", "hls" -> ExoPlayerTile(camera = camera, modifier = modifier)
        else -> Box(modifier = modifier.background(Color.DarkGray), contentAlignment = Alignment.Center) {
            Text(text = "Unsupported: ${camera.streamType}", color = Color.White)
        }
    }
}

@Composable
private fun ExoPlayerTile(camera: CameraDto, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val player = remember(camera.url) {
        ExoPlayer.Builder(context).build().apply {
            setMediaItem(MediaItem.fromUri(Uri.parse(camera.url)))
            prepare()
            playWhenReady = true
            volume = 0f
        }
    }

    DisposableEffect(player) {
        onDispose { player.release() }
    }

    AndroidView(
        modifier = modifier.fillMaxSize(),
        factory = {
            PlayerView(it).apply {
                useController = false
                this.player = player
            }
        }
    )
}
