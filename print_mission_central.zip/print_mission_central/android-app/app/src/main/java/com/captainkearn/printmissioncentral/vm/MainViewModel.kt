package com.captainkearn.printmissioncentral.vm

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.captainkearn.printmissioncentral.data.DashboardResponse
import com.captainkearn.printmissioncentral.data.Repository
import com.captainkearn.printmissioncentral.data.SettingsStore
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch

sealed interface DashboardState {
    data object Loading : DashboardState
    data class Ready(val dashboard: DashboardResponse, val serverUrl: String, val layoutName: String) : DashboardState
    data class Error(val message: String, val serverUrl: String, val layoutName: String) : DashboardState
}

class MainViewModel(
    private val repository: Repository,
    private val settingsStore: SettingsStore
) : ViewModel() {
    private val _state = MutableStateFlow<DashboardState>(DashboardState.Loading)
    val state: StateFlow<DashboardState> = _state.asStateFlow()

    init {
        viewModelScope.launch {
            combine(settingsStore.serverUrl, settingsStore.layoutName) { url, layout -> url to layout }
                .collect { (url, layout) ->
                    fetch(url, layout)
                }
        }
    }

    fun fetch(serverUrl: String, layoutName: String) {
        viewModelScope.launch {
            _state.value = DashboardState.Loading
            runCatching {
                repository.api(serverUrl).getDashboard(layoutName)
            }.onSuccess {
                _state.value = DashboardState.Ready(it, serverUrl, layoutName)
            }.onFailure {
                _state.value = DashboardState.Error(it.message ?: "Unknown error", serverUrl, layoutName)
            }
        }
    }

    fun saveSettings(serverUrl: String, layoutName: String) {
        viewModelScope.launch {
            settingsStore.saveServerUrl(serverUrl)
            settingsStore.saveLayoutName(layoutName)
        }
    }

    class Factory(
        private val repository: Repository,
        private val settingsStore: SettingsStore
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return MainViewModel(repository, settingsStore) as T
        }
    }
}
