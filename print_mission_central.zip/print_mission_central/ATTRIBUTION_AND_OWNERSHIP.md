# Attribution and Ownership

This Print Mission Central code package was created for **Captain Kearn / Ryan Ghering** with AI-assisted code generation.

## Attribution
Recommended credit line:

> Initial codebase generated with assistance from OpenAI ChatGPT for Captain Kearn.

## Ownership and use rights
As delivered here, you may:
- use the code for personal or commercial projects
- modify the code
- distribute the code
- keep the code private
- publish derivative works
- rebrand the project

## Important note about dependencies
This project relies on third-party frameworks and libraries such as FastAPI, Requests, AndroidX, Media3, Retrofit, OkHttp, and Kotlin serialization. Those dependencies remain subject to their own licenses.

## Plain-English summary
The delivered project is yours to build on. The AI helped generate the starter code, but you can treat this as your project and continue developing it however you want, while still respecting the licenses of the libraries it uses.
