@echo off
cd /d %~dp0
py -m venv .venv 2>nul || python -m venv .venv
call .venv\Scripts\activate
python -m pip install --upgrade pip
python ensure_dependencies.py
python app.py
