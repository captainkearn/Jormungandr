from __future__ import annotations

import base64
import hashlib
import hmac
import json
import secrets
import socket
import threading
import time
from pathlib import Path
from typing import Literal
from urllib.parse import urlparse

import ipaddress
import requests
from zeroconf import IPVersion, ServiceInfo, Zeroconf
from fastapi import Depends, FastAPI, Form, Header, HTTPException, Request
from fastapi.responses import HTMLResponse, JSONResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel, Field, field_validator

APP_DIR = Path(__file__).parent
DATA_DIR = APP_DIR / "data"
CONFIG_FILE = DATA_DIR / "config.json"
DISCOVERY_PORT = 8182
DISCOVERY_MAGIC = "PMC_DISCOVER_V2"
MDNS_SERVICE_TYPE = "_printmission._tcp.local."
MDNS_SERVICE_NAME = "Print Mission Central._printmission._tcp.local."
MDNS_HOSTNAME = "printmissioncentral.local."
PAIRING_TOKEN_TTL_SECONDS = 3600 * 24 * 365 * 5  # long-lived local appliance tokens
ADMIN_DEFAULT_USER = "admin"
ADMIN_DEFAULT_PASSWORD = "admin"

app = FastAPI(title="Print Mission Central Local Server")
app.mount("/static", StaticFiles(directory=str(APP_DIR / "static")), name="static")
templates = Jinja2Templates(directory=str(APP_DIR / "templates"))


class Camera(BaseModel):
    id: str = Field(..., min_length=1)
    printer_name: str = Field(..., min_length=1)
    url: str = Field(..., min_length=1)
    stream_type: Literal["mjpeg", "rtsp", "hls", "snapshot"] = "mjpeg"
    enabled: bool = True
    notes: str = ""

    @field_validator("url")
    @classmethod
    def validate_local_url(cls, value: str) -> str:
        parsed = urlparse(value)
        if parsed.scheme.lower() not in {"http", "https", "rtsp"}:
            raise ValueError("Only http, https, and rtsp URLs are allowed")
        if not parsed.hostname:
            raise ValueError("Camera URL must include a hostname")
        if not is_local_host(parsed.hostname):
            raise ValueError("Camera host must be on the local/private network")
        return value


class LayoutItem(BaseModel):
    camera_id: str
    row: int = 0
    col: int = 0
    row_span: int = 1
    col_span: int = 1


class Layout(BaseModel):
    name: str = Field(..., min_length=1)
    rows: int = Field(default=2, ge=1, le=8)
    cols: int = Field(default=2, ge=1, le=8)
    items: list[LayoutItem] = Field(default_factory=list)


class ThemeSettings(BaseModel):
    background_color: str = "#000000"
    tile_outline_color: str = "#00B7FF"


class AdminSettings(BaseModel):
    username: str = ADMIN_DEFAULT_USER
    password: str = ADMIN_DEFAULT_PASSWORD


class ApiToken(BaseModel):
    token: str
    label: str = "TV App"
    created_at: int
    last_seen_at: int | None = None
    expires_at: int | None = None


class ConfigModel(BaseModel):
    cameras: list[Camera] = Field(default_factory=list)
    layouts: list[Layout] = Field(default_factory=list)
    default_layout: str = "Default"
    theme: ThemeSettings = Field(default_factory=ThemeSettings)
    admin: AdminSettings = Field(default_factory=AdminSettings)
    api_tokens: list[ApiToken] = Field(default_factory=list)


class ThemeUpdate(BaseModel):
    background_color: str
    tile_outline_color: str


class CredentialsUpdate(BaseModel):
    username: str
    password: str


class PairRequest(BaseModel):
    device_name: str = "TV Device"


class DiscoveryResponder(threading.Thread):
    daemon = True

    def __init__(self) -> None:
        super().__init__(name="pmc-discovery")
        self.running = True
        self.sock: socket.socket | None = None

    def stop(self) -> None:
        self.running = False
        if self.sock:
            try:
                self.sock.close()
            except OSError:
                pass

    def run(self) -> None:
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
            sock.bind(("", DISCOVERY_PORT))
            self.sock = sock
        except OSError:
            return

        while self.running:
            try:
                data, addr = sock.recvfrom(4096)
            except OSError:
                break
            if not data:
                continue
            text = data.decode("utf-8", errors="ignore").strip()
            if text != DISCOVERY_MAGIC:
                continue
            ip = local_ip_for(addr[0])
            payload = {
                "name": "Print Mission Central",
                "api_base": f"http://{ip}:8181",
                "web_ui": f"http://{ip}:8181/",
                "discovery_port": DISCOVERY_PORT,
                "api_version": 2,
                "time": int(time.time()),
            }
            try:
                sock.sendto(json.dumps(payload).encode("utf-8"), addr)
            except OSError:
                pass


def is_local_host(hostname: str) -> bool:
    if hostname == "localhost" or hostname.endswith(".local"):
        return True

    try:
        ip = ipaddress.ip_address(hostname)
        return ip.is_private or ip.is_loopback or ip.is_link_local
    except ValueError:
        pass

    try:
        infos = socket.getaddrinfo(hostname, None)
        found_any = False
        for info in infos:
            candidate = info[4][0]
            ip = ipaddress.ip_address(candidate)
            found_any = True
            if not (ip.is_private or ip.is_loopback or ip.is_link_local):
                return False
        return found_any
    except socket.gaierror:
        return False


def local_ip_for(remote_hint: str = "8.8.8.8") -> str:
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
            s.connect((remote_hint, 80))
            return s.getsockname()[0]
    except OSError:
        return "127.0.0.1"




def register_mdns_service() -> tuple[Zeroconf, ServiceInfo] | tuple[None, None]:
    ip = local_ip_for()
    if ip == "127.0.0.1":
        return None, None

    info = ServiceInfo(
        MDNS_SERVICE_TYPE,
        MDNS_SERVICE_NAME,
        addresses=[socket.inet_aton(ip)],
        port=8181,
        properties={
            b"path": b"/",
            b"api_version": b"2",
            b"discovery_magic": DISCOVERY_MAGIC.encode("utf-8"),
        },
        server=MDNS_HOSTNAME,
    )
    zc = Zeroconf(ip_version=IPVersion.V4Only)
    zc.register_service(info, allow_name_change=True)
    return zc, info

def default_config() -> ConfigModel:
    return ConfigModel(
        cameras=[],
        layouts=[Layout(name="Default", rows=2, cols=2, items=[])],
        default_layout="Default",
    )


def load_config() -> ConfigModel:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    if not CONFIG_FILE.exists():
        cfg = default_config()
        save_config(cfg)
        return cfg
    with CONFIG_FILE.open("r", encoding="utf-8") as f:
        data = json.load(f)
    return ConfigModel.model_validate(data)


def save_config(cfg: ConfigModel) -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    with CONFIG_FILE.open("w", encoding="utf-8") as f:
        json.dump(cfg.model_dump(), f, indent=2)


def auth_ok(auth_header: str | None, cfg: ConfigModel) -> bool:
    if not auth_header or not auth_header.startswith("Basic "):
        return False
    try:
        raw = base64.b64decode(auth_header.split(" ", 1)[1]).decode("utf-8")
        username, password = raw.split(":", 1)
    except Exception:
        return False
    return username == cfg.admin.username and password == cfg.admin.password


def require_auth(authorization: str | None = Header(default=None)) -> ConfigModel:
    cfg = load_config()
    if not auth_ok(authorization, cfg):
        raise HTTPException(status_code=401, detail="Unauthorized", headers={"WWW-Authenticate": "Basic"})
    return cfg


def touch_api_token(cfg: ConfigModel, token: str) -> None:
    now = int(time.time())
    changed = False
    valid_tokens: list[ApiToken] = []
    for entry in cfg.api_tokens:
        if entry.expires_at and entry.expires_at < now:
            changed = True
            continue
        if hmac.compare_digest(entry.token, token):
            entry.last_seen_at = now
            changed = True
        valid_tokens.append(entry)
    cfg.api_tokens = valid_tokens
    if changed:
        save_config(cfg)


def require_api_token(x_pmc_token: str | None = Header(default=None, alias="X-PMC-Token")) -> ConfigModel:
    cfg = load_config()
    if not x_pmc_token:
        raise HTTPException(status_code=401, detail="Missing API token")
    now = int(time.time())
    for entry in cfg.api_tokens:
        if entry.expires_at and entry.expires_at < now:
            continue
        if hmac.compare_digest(entry.token, x_pmc_token):
            touch_api_token(cfg, x_pmc_token)
            return cfg
    raise HTTPException(status_code=401, detail="Invalid API token")


def validate_layout(layout: Layout, cfg: ConfigModel) -> None:
    camera_ids = {c.id for c in cfg.cameras}
    occupied: set[tuple[int, int]] = set()
    for item in layout.items:
        if item.camera_id not in camera_ids:
            raise HTTPException(status_code=400, detail=f"Unknown camera: {item.camera_id}")
        if item.row < 0 or item.col < 0:
            raise HTTPException(status_code=400, detail="Layout positions must be non-negative")
        if item.row + item.row_span > layout.rows or item.col + item.col_span > layout.cols:
            raise HTTPException(status_code=400, detail=f"Camera {item.camera_id} exceeds layout bounds")
        for r in range(item.row, item.row + item.row_span):
            for c in range(item.col, item.col + item.col_span):
                cell = (r, c)
                if cell in occupied:
                    raise HTTPException(status_code=400, detail=f"Overlapping layout items at row {r}, col {c}")
                occupied.add(cell)


def check_camera_health(camera: Camera, timeout: float = 2.5) -> dict:
    parsed = urlparse(camera.url)
    scheme = parsed.scheme.lower()
    if not camera.enabled:
        return {"status": "disabled", "healthy": False, "detail": "Camera disabled"}
    try:
        if scheme in {"http", "https"}:
            resp = requests.get(camera.url, timeout=timeout, stream=True)
            ct = resp.headers.get("content-type", "")
            code = resp.status_code
            resp.close()
            healthy = code < 400
            detail = f"HTTP {code}" + (f" · {ct}" if ct else "")
            return {"status": "online" if healthy else "error", "healthy": healthy, "detail": detail}
        if scheme == "rtsp":
            host = parsed.hostname
            port = parsed.port or 554
            with socket.create_connection((host, port), timeout=timeout):
                pass
            return {"status": "online", "healthy": True, "detail": f"RTSP {host}:{port} reachable"}
    except Exception as exc:
        return {"status": "offline", "healthy": False, "detail": str(exc)[:180]}
    return {"status": "unknown", "healthy": False, "detail": "Unsupported stream type for probing"}


@app.on_event("startup")
def startup_event() -> None:
    responder = DiscoveryResponder()
    responder.start()
    app.state.discovery_responder = responder

    try:
        zc, info = register_mdns_service()
        app.state.zeroconf = zc
        app.state.zeroconf_info = info
    except Exception as exc:
        app.state.zeroconf = None
        app.state.zeroconf_info = None
        print(f"mDNS registration failed: {exc}")


@app.on_event("shutdown")
def shutdown_event() -> None:
    responder: DiscoveryResponder | None = getattr(app.state, "discovery_responder", None)
    if responder:
        responder.stop()

    zc: Zeroconf | None = getattr(app.state, "zeroconf", None)
    info: ServiceInfo | None = getattr(app.state, "zeroconf_info", None)
    if zc and info:
        try:
            zc.unregister_service(info)
        except Exception:
            pass
        finally:
            zc.close()


@app.get("/", response_class=HTMLResponse)
def index(request: Request, cfg: ConfigModel = Depends(require_auth)):
    return templates.TemplateResponse(
        request,
        "index.html",
        {
            "config": cfg,
            "server_ip": local_ip_for(),
        },
    )


@app.get("/api/discovery")
def api_discovery():
    ip = local_ip_for()
    return {
        "name": "Print Mission Central",
        "api_base": f"http://{ip}:8181",
        "web_ui": f"http://{ip}:8181/",
        "discovery_port": DISCOVERY_PORT,
        "api_version": 2,
        "mdns": {
            "service_type": MDNS_SERVICE_TYPE,
            "service_name": MDNS_SERVICE_NAME,
            "hostname": MDNS_HOSTNAME,
            "url": f"http://{MDNS_HOSTNAME.rstrip('.')}:{8181}/",
        },
    }


@app.post("/api/pair")
def pair_device(payload: PairRequest, cfg: ConfigModel = Depends(require_auth)):
    token = secrets.token_urlsafe(32)
    now = int(time.time())
    cfg.api_tokens.append(
        ApiToken(
            token=token,
            label=payload.device_name[:80] or "TV Device",
            created_at=now,
            last_seen_at=now,
            expires_at=now + PAIRING_TOKEN_TTL_SECONDS,
        )
    )
    save_config(cfg)
    return {
        "token": token,
        "server": "Print Mission Central",
        "default_layout": cfg.default_layout,
        "theme": cfg.theme.model_dump(),
    }


@app.get("/api/layouts")
def get_layouts(cfg: ConfigModel = Depends(require_api_token)):
    return {
        "default_layout": cfg.default_layout,
        "layouts": [{"name": layout.name, "rows": layout.rows, "cols": layout.cols} for layout in cfg.layouts],
        "theme": cfg.theme.model_dump(),
    }


@app.get("/api/dashboard/{layout_name}")
def get_dashboard(layout_name: str, cfg: ConfigModel = Depends(require_api_token)):
    layout = next((l for l in cfg.layouts if l.name == layout_name), None)
    if not layout:
        raise HTTPException(status_code=404, detail="Layout not found")
    cameras = {c.id: c for c in cfg.cameras if c.enabled}
    health_map = {camera.id: check_camera_health(camera) for camera in cameras.values()}
    items = []
    for item in layout.items:
        camera = cameras.get(item.camera_id)
        if camera:
            items.append({
                **item.model_dump(),
                "camera": camera.model_dump(),
                "health": health_map.get(camera.id, {"status": "unknown", "healthy": False, "detail": "No data"}),
            })
    return {
        "layout": layout.name,
        "rows": layout.rows,
        "cols": layout.cols,
        "items": items,
        "default_layout": cfg.default_layout,
        "theme": cfg.theme.model_dump(),
    }


@app.get("/api/config")
def get_config(cfg: ConfigModel = Depends(require_auth)):
    return cfg.model_dump()


@app.get("/api/health")
def get_health(cfg: ConfigModel = Depends(require_auth)):
    return {camera.id: check_camera_health(camera) for camera in cfg.cameras}


@app.post("/api/cameras")
def add_camera(camera: Camera, cfg: ConfigModel = Depends(require_auth)):
    if any(c.id == camera.id for c in cfg.cameras):
        raise HTTPException(status_code=400, detail="Camera ID already exists")
    cfg.cameras.append(camera)
    save_config(cfg)
    return {"ok": True}


@app.put("/api/cameras/{camera_id}")
def update_camera(camera_id: str, camera: Camera, cfg: ConfigModel = Depends(require_auth)):
    for idx, existing in enumerate(cfg.cameras):
        if existing.id == camera_id:
            cfg.cameras[idx] = camera
            save_config(cfg)
            return {"ok": True}
    raise HTTPException(status_code=404, detail="Camera not found")


@app.delete("/api/cameras/{camera_id}")
def delete_camera(camera_id: str, cfg: ConfigModel = Depends(require_auth)):
    before = len(cfg.cameras)
    cfg.cameras = [c for c in cfg.cameras if c.id != camera_id]
    for layout in cfg.layouts:
        layout.items = [i for i in layout.items if i.camera_id != camera_id]
    if len(cfg.cameras) == before:
        raise HTTPException(status_code=404, detail="Camera not found")
    save_config(cfg)
    return {"ok": True}


@app.post("/api/layouts")
def add_layout(layout: Layout, cfg: ConfigModel = Depends(require_auth)):
    if any(l.name == layout.name for l in cfg.layouts):
        raise HTTPException(status_code=400, detail="Layout already exists")
    validate_layout(layout, cfg)
    cfg.layouts.append(layout)
    save_config(cfg)
    return {"ok": True}


@app.put("/api/layouts/{layout_name}")
def update_layout(layout_name: str, layout: Layout, cfg: ConfigModel = Depends(require_auth)):
    validate_layout(layout, cfg)
    for idx, existing in enumerate(cfg.layouts):
        if existing.name == layout_name:
            cfg.layouts[idx] = layout
            if cfg.default_layout == layout_name:
                cfg.default_layout = layout.name
            save_config(cfg)
            return {"ok": True}
    raise HTTPException(status_code=404, detail="Layout not found")


@app.delete("/api/layouts/{layout_name}")
def delete_layout(layout_name: str, cfg: ConfigModel = Depends(require_auth)):
    if layout_name == cfg.default_layout:
        raise HTTPException(status_code=400, detail="Cannot delete the default layout")
    before = len(cfg.layouts)
    cfg.layouts = [l for l in cfg.layouts if l.name != layout_name]
    if len(cfg.layouts) == before:
        raise HTTPException(status_code=404, detail="Layout not found")
    save_config(cfg)
    return {"ok": True}


@app.post("/api/default-layout/{layout_name}")
def set_default_layout(layout_name: str, cfg: ConfigModel = Depends(require_auth)):
    if not any(l.name == layout_name for l in cfg.layouts):
        raise HTTPException(status_code=404, detail="Layout not found")
    cfg.default_layout = layout_name
    save_config(cfg)
    return {"ok": True}


@app.put("/api/theme")
def update_theme(theme: ThemeUpdate, cfg: ConfigModel = Depends(require_auth)):
    cfg.theme = ThemeSettings(**theme.model_dump())
    save_config(cfg)
    return {"ok": True}


@app.put("/api/admin")
def update_admin(creds: CredentialsUpdate, cfg: ConfigModel = Depends(require_auth)):
    cfg.admin = AdminSettings(**creds.model_dump())
    save_config(cfg)
    return {"ok": True}


@app.delete("/api/tokens/{token_hash}")
def delete_token(token_hash: str, cfg: ConfigModel = Depends(require_auth)):
    before = len(cfg.api_tokens)
    cfg.api_tokens = [t for t in cfg.api_tokens if hashlib.sha1(t.token.encode()).hexdigest()[:12] != token_hash]
    if len(cfg.api_tokens) == before:
        raise HTTPException(status_code=404, detail="Token not found")
    save_config(cfg)
    return {"ok": True}


@app.post("/ui/cameras")
def ui_add_camera(
    camera_id: str = Form(...),
    printer_name: str = Form(...),
    url: str = Form(...),
    stream_type: str = Form(...),
    enabled: bool = Form(False),
    notes: str = Form(""),
    cfg: ConfigModel = Depends(require_auth),
):
    add_camera(Camera(id=camera_id, printer_name=printer_name, url=url, stream_type=stream_type, enabled=enabled, notes=notes), cfg)
    return RedirectResponse(url="/", status_code=303)




@app.post("/ui/cameras/{camera_id}/edit")
def ui_edit_camera(
    camera_id: str,
    new_camera_id: str = Form(...),
    printer_name: str = Form(...),
    url: str = Form(...),
    stream_type: str = Form(...),
    enabled: bool = Form(False),
    notes: str = Form(""),
    cfg: ConfigModel = Depends(require_auth),
):
    target = next((c for c in cfg.cameras if c.id == camera_id), None)
    if target is None:
        raise HTTPException(status_code=404, detail="Camera not found")
    if new_camera_id != camera_id and any(c.id == new_camera_id for c in cfg.cameras):
        raise HTTPException(status_code=400, detail="Camera ID already exists")

    updated = Camera(
        id=new_camera_id,
        printer_name=printer_name,
        url=url,
        stream_type=stream_type,
        enabled=enabled,
        notes=notes,
    )
    for idx, existing in enumerate(cfg.cameras):
        if existing.id == camera_id:
            cfg.cameras[idx] = updated
            break
    if new_camera_id != camera_id:
        for layout in cfg.layouts:
            for item in layout.items:
                if item.camera_id == camera_id:
                    item.camera_id = new_camera_id
    save_config(cfg)
    return RedirectResponse(url="/", status_code=303)


@app.post("/ui/cameras/{camera_id}/delete")
def ui_delete_camera(camera_id: str, cfg: ConfigModel = Depends(require_auth)):
    delete_camera(camera_id, cfg)
    return RedirectResponse(url="/", status_code=303)


@app.post("/ui/theme")
def ui_theme(background_color: str = Form(...), tile_outline_color: str = Form(...), cfg: ConfigModel = Depends(require_auth)):
    update_theme(ThemeUpdate(background_color=background_color, tile_outline_color=tile_outline_color), cfg)
    return RedirectResponse(url="/", status_code=303)


@app.post("/ui/admin")
def ui_admin(username: str = Form(...), password: str = Form(...), cfg: ConfigModel = Depends(require_auth)):
    update_admin(CredentialsUpdate(username=username, password=password), cfg)
    return RedirectResponse(url="/", status_code=303)


@app.post("/ui/pair")
def ui_pair(device_name: str = Form("TV Device"), cfg: ConfigModel = Depends(require_auth)):
    pair_device(PairRequest(device_name=device_name), cfg)
    return RedirectResponse(url="/", status_code=303)


@app.post("/ui/layouts/save")
def ui_save_layout(payload: dict, cfg: ConfigModel = Depends(require_auth)):
    layout = Layout.model_validate(payload)
    existing = next((l for l in cfg.layouts if l.name == layout.name), None)
    validate_layout(layout, cfg)
    if existing is None:
        cfg.layouts.append(layout)
    else:
        idx = cfg.layouts.index(existing)
        cfg.layouts[idx] = layout
    save_config(cfg)
    return {"ok": True}


@app.get("/api/export")
def export_config(cfg: ConfigModel = Depends(require_auth)):
    return JSONResponse(content=cfg.model_dump())


@app.get("/api/app-setup")
def app_setup(cfg: ConfigModel = Depends(require_auth)):
    """Convenience endpoint for manual testing / future QR flow."""
    ip = local_ip_for()
    return {
        "server_url": f"http://{ip}:8181",
        "default_layout": cfg.default_layout,
        "pairing_hint": "Use /api/pair with basic auth once, then store the returned token in the TV app.",
    }


if __name__ == "__main__":
    import uvicorn

    uvicorn.run("app:app", host="0.0.0.0", port=8181, reload=False)
