from __future__ import annotations

import importlib
import subprocess
import sys
from pathlib import Path

APP_DIR = Path(__file__).parent
REQ_FILE = APP_DIR / "requirements.txt"
MODULE_OVERRIDES = {
    "uvicorn[standard]": "uvicorn",
    "python-multipart": "multipart",
}


def requirement_to_module(requirement: str) -> str:
    name = requirement.split("==", 1)[0].strip()
    return MODULE_OVERRIDES.get(name, name.replace("-", "_"))


def main() -> int:
    if not REQ_FILE.exists():
        print("requirements.txt not found; skipping dependency check")
        return 0

    requirements = [
        line.strip()
        for line in REQ_FILE.read_text(encoding="utf-8").splitlines()
        if line.strip() and not line.strip().startswith("#")
    ]
    missing: list[str] = []
    for requirement in requirements:
        module_name = requirement_to_module(requirement)
        try:
            importlib.import_module(module_name)
        except Exception:
            missing.append(requirement)

    if not missing:
        print("Dependency check: all required Python packages are installed.")
        return 0

    print("Dependency check: installing missing packages:")
    for item in missing:
        print(f"  - {item}")

    subprocess.check_call([sys.executable, "-m", "pip", "install", *missing])
    print("Dependency check: installation complete.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
