#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
python3 -m venv .venv
source .venv/bin/activate
python3 -m pip install --upgrade pip
python3 ensure_dependencies.py
python3 app.py
