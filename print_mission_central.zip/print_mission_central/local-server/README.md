# Print Mission Central Local Server

This is the local-only server for Print Mission Central.

## Features
- Local/private IP camera validation only
- Basic admin login enabled by default: `admin` / `admin`
- Editable admin credentials in the web UI
- Theme editor for dashboard background and camera outline color
- Drag-and-drop layout editor
- Camera health/status checks
- UDP auto-discovery for the Android TV app

## Run
### Linux
```bash
./start-linux.sh
```

### Windows
Run `start-windows.bat`

Then open:
- `http://YOUR-SERVER-IP:8181/`

Use the default login:
- Username: `admin`
- Password: `admin`

## Discovery
The server listens for UDP discovery requests on port `8182` and responds with its local API address.

## Notes
This is intended for a trusted home LAN. For stronger security later, add hashed passwords and TLS.
